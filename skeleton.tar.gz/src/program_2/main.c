#include <scwrapper.h>

int
main(int argc, char* argv[])
{
 prints("Ta da!\n");
}
