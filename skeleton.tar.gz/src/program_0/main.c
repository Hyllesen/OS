#include <scwrapper.h>

int 
main(int argc, char* argv[])
{
 prints("Starting process 0\n");

 while(1);
 
 return 0;
}
